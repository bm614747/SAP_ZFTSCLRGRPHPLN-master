sap.ui.define([],
    function() {
        'use strict';
    
        var constants = {
            serviceURL: "/sap/opu/odata/sap/",
            service: "ZFTS_GW_PRODUCTCOLOR_SRV",
            entitySet: "ProductColorSet",
            excelFileName: "Test-COlor.xlsx"
        };
    
        return constants;
    });