sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (JSNOModel, MessageBox) {
    "use strict";

    return {
        /**
         * Initialization of events for upload
         * @param {object} 
         *	oRef - Reference of where the commonuploadUI.fragment.xml used.
         *	sService - oData Service name
         *	sUploadEntity - Create stream entity name for upload
         * 
         * 
         */
        init: function (initData) {




            this.initData = initData;
            // if (initData.oRef) {
            initData.oRef.getView().setModel(new JSNOModel([]), "EXCEL_RESULTS_MODEL");

            //  Called if mismatch in file type
            initData.oRef.byId("idFileUploader").attachTypeMissmatch(function () {
                MessageBox.error(initData.oRef.getView().getModel("i18n").getResourceBundle().getText("validtypemessageBoxError"));
            }.bind(initData.oRef));
        },

        //change event
        handleUploadChange: function (oEvent) {
            if (oEvent.getParameter("files") && oEvent.getParameter("files")[0]) {
                this.addHeaderParameters();
            }
        },


        //Add header parameters and sets the uplodUrl
        addHeaderParameters: function () {
            if (this.initData.oRef.getView().byId("idChkBox").getSelected()) {
                this.sTestRunValue = "X";
            } else {
                this.sTestRunValue = "";
            }
            this.initData.oRef.getView().setBusy(true);
            var oCustomerHeaderToken = new sap.ui.unified.FileUploaderParameter({
                name: "x-csrf-token",
                value: this.initData.oRef.getView().getModel().getSecurityToken()
            });
            this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oCustomerHeaderToken);
            var oSlug;
            if (this.sTestRunValue) {
                this.initData.oRef.getView().byId("idFileUploader").removeAllHeaderParameters();
                oSlug = new sap.ui.unified.FileUploaderParameter({
                    name: "slug",
                    value: this.initData.oRef.getView().byId("idFileUploader").getValue() + "|" + this.sTestRunValue
                });
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oCustomerHeaderToken);
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oSlug);
            } else {
                this.initData.oRef.getView().byId("idFileUploader").removeAllHeaderParameters();
                oSlug = new sap.ui.unified.FileUploaderParameter({
                    name: "slug",
                    value: this.initData.oRef.getView().byId("idFileUploader").getValue()
                });
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oCustomerHeaderToken);
                this.initData.oRef.getView().byId("idFileUploader").addHeaderParameter(oSlug);
            }

            var sUploadURL = this.initData.sServiceURL + this.initData.sService + "/" + this.initData.sUploadEntity;
            this.initData.oRef.getView().byId("idFileUploader").setUploadUrl(sUploadURL);
            this.initData.oRef.getView().setBusy(false);
        },

        //upload complete method 
        handleComplete: function (oEvent) {
            var oResponse = (new window.DOMParser()).parseFromString(oEvent.getParameter("responseRaw"), "text/xml");
            if (oResponse.childNodes[0].children[6].children.length > 0) {
                var aItem = oResponse.childNodes[0].children[6].children[2];
                this.parseMessages(aItem.innerHTML);
            }
            this.initData.oRef.getView().byId("idFileUploader").clear();
            this.initData.oRef.getView().byId("idFileUploader").removeAllHeaderParameters();
            this.initData.oRef.getView().setBusy(false);
        },

        //Parsing data and assigning to objects
        parseMessages: function (aItems) {
            var aExcelData = [];
            var aData = aItems.split("\n");
            for (var i = 0; i <= aData.length - 2; i++) {
                var oExcelObjects = {};
                oExcelObjects.PLANT = aData[i].split("||")[0];
                oExcelObjects.MATERIALCODE = aData[i].split("||")[1];
                oExcelObjects.MATERIALDESCRIPTION = aData[i].split("||")[2];
                oExcelObjects.COLORCODE = aData[i].split("||")[3];
                oExcelObjects.SORTCRITERIA = aData[i].split("||")[4];
                oExcelObjects.STATUS = aData[i].split("||")[5];
                oExcelObjects.MESSAGE = aData[i].split("||")[6];
                aExcelData.push(oExcelObjects);
            }

            // Setting data to the model
            this.initData.oRef.getView().getModel("EXCEL_RESULTS_MODEL").setData(aExcelData);
        }
    };
});