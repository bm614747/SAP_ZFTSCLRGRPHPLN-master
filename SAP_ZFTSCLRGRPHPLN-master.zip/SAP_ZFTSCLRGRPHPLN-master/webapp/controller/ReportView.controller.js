sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/type/String",
    "sap/m/ColumnListItem",
    "sap/m/Label",
    "sap/m/SearchField",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/table/Column",
    "sap/m/Column",
    "sap/m/Text",
    "sap/m/Input",
    "sap/m/Button",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "zftsclrcodegraphplnboard/utils/CommonUpload",
    "zftsclrcodegraphplnboard/utils/Constants",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, TypeString, ColumnListItem, Label, SearchField, Filter, FilterOperator, UIColumn, MColumn, Text, Input, Button, MessageBox, JSONModel, Fragment, CommonUpload, Constants, exportLibrary, Spreadsheet) {
        "use strict";
        var oView;
        var opayloadItems = [];
        var odeleteItems = [];
        var oeditItems = [];
        var EdmType = exportLibrary.EdmType;

        return Controller.extend("zftsclrcodegraphplnboard.controller.ReportView", {
            onInit: function () {
                var that = this;
                oView = this.getView();
                //Setting F4 value help for color code
                that.getOwnerComponent().getModel().read("/HWcolSet", {
                    success: $.proxy(function (oResponse) {
                        this.getView().setModel(new JSONModel([]), "COLOR_CODE_RESULTS_MODEL");
                        this.getView().getModel("COLOR_CODE_RESULTS_MODEL").setData(oResponse.results);
                    }, this),
                    error: function (oError) {
                    }
                });
                //Setting F4 value help for Plant Code
                that.getOwnerComponent().getModel().read("/HT001wSet", {
                    success: $.proxy(function (oResponse) {
                        this.getView().setModel(new JSONModel([]), "PLANT_RESULTS_MODEL");
                        this.getView().getModel("PLANT_RESULTS_MODEL").setData(oResponse.results);
                    }, this),
                    error: function (oError) {
                    }
                });

                //Setting data for MainModel being used in the main page header section

                this.getView().setModel(new JSONModel([]), "MainModel");
                var aMainModelData = [];
                var oMainModelObjects = {};
                oMainModelObjects.PlantCodeValue = "";
                aMainModelData.push(oMainModelObjects);
                this.getView().getModel("MainModel").setData(aMainModelData);

                // Setting PlantCreate Model  being used when manually creating entry using create button
                this.getView().setModel(new JSONModel([]), "PlantCreateModel");
                var aPlantCreateModelData = [];
                var oPlantCreateModelObjects = {};
                oPlantCreateModelObjects.Pressed = false;
                oPlantCreateModelObjects.path = "";
                oPlantCreateModelObjects.ColorCodeValue = "";
                oPlantCreateModelObjects.MaterialCodeValue = "";
                oPlantCreateModelObjects.MaterialDescription = "";
                oPlantCreateModelObjects.PlantCodeValue = "";
                oPlantCreateModelObjects.SortCriteria = "";
                oPlantCreateModelObjects.MRPType = "";
                oPlantCreateModelObjects.AdvancePlanning = "";
                aPlantCreateModelData.push(oPlantCreateModelObjects);
                this.getView().getModel("PlantCreateModel").setData(aPlantCreateModelData);


                this.oTable = this.byId("exportTable");
                this.oPlantTable = this.byId("exportPlantTable");
                this.oReadOnlyTemplate = this.getView().byId("idColumnListItem");
                this.oPlantReadOnlyTemplate = this.getView().byId("idPTColumnListItem");

                // Passing reference of contansts to utility file for data upload
                CommonUpload.init({
                    oRef: this,
                    sServiceURL: Constants.serviceURL,
                    sService: Constants.service,
                    sUploadEntity: Constants.entitySet
                })

                //Setting editable template for Edit functionality
                this.oEditableTemplate = new ColumnListItem({
                    cells: [
                        new Text({
                            text: "{PLANT_EXCEL_RESULTS_MODEL>Werks}"
                        }), new Text({
                            text: "{PLANT_EXCEL_RESULTS_MODEL>Matnr}"
                        }), new Text({
                            text: "{PLANT_EXCEL_RESULTS_MODEL>Maktx}"
                        }), new Input({
                            value: "{PLANT_EXCEL_RESULTS_MODEL>ZzcolorCode}",
                            showValueHelp: true,
                            valueHelpOnly: true,
                            valueHelpRequest: function (oEvent) {
                                that.onColorCodeHelpRequested(oEvent);
                            },
                            change: function () {
                                sap.m.MessageToast.show(this.getValue());
                            }
                        }),
                        new Input({
                            value: "{PLANT_EXCEL_RESULTS_MODEL>ZzsortCriteria}",
                            change: function (oEvent) {
                                that.onsortChange(oEvent);
                            }
                        }),
                        new Text({
                            text: "{PLANT_EXCEL_RESULTS_MODEL>Dismm}"
                        }),
                        new Text({
                            text: "{= ${PLANT_EXCEL_RESULTS_MODEL>Ppskz} === true ? 'X' : '' }"
                        }),
                        new Button({
                            icon: "sap-icon://delete",
                            visible: false,
                            press: function (oEvent) {
                                that.handleDeleteAttachment(oEvent);
                            }
                        })
                    ]
                });

            },

            // Functiona to handle test run functionality
            handleSelect: function () {
                // Calling add header function in utility file
                CommonUpload.addHeaderParameters();
            },

            // Execute button functiontionality
            handlePress: function (oEvent) {
                var that = this;
                opayloadItems = [];
                odeleteItems = [];
                oeditItems = [];
                that.oReadOnlyTemplate = this.getView().byId("idColumnListItem");

                //Read Template is binded by default for fileuploader table
                that.rebindTable(this.oReadOnlyTemplate, "Navigation");

                //Read Template is binded by default for Export Plant table
                that.oPlantReadOnlyTemplate = this.getView().byId("idPTColumnListItem");
                that.plantRebindTable(this.oPlantReadOnlyTemplate, "Navigation");

                //validation condition to check material or plant value or file is maintained
                if ((oView.byId("idMainMaterial").getTokens().length >= 1 || oView.byId("idMainPlant").getValue() !== '') || (this.byId("idFileUploader").getValue())) {

                    if (that.byId("idFileUploader").getValue()) {
                        oView.byId("idSave").setVisible(false);
                        oView.byId("idCancel").setVisible(true);
                        oView.byId("exportTable").setVisible(true);
                        oView.byId("exportPlantTable").setVisible(false);
                        that.byId("idFileUploader").upload();
                    }
                    //validation of material and plant combination to be maintained
                    else if ((oView.byId("idMainMaterial").getTokens().length >= 1)) {
                        if (oView.byId("idMainPlant").getValue()) {
                            var sPlantValue = oView.byId("idMainPlant").getValue();
                            oView.byId("idSave").setVisible(true);
                            oView.byId("idCancel").setVisible(true);

                            var sMaterialValue, skeyValue;

                            //Maintaing filter value for mutiple materials
                            if (oView.byId("idMainMaterial").getTokens().length > 1) {
                                var sMatValue = "";
                                oView.byId("idMainMaterial").getTokens().forEach(function (oValue, i) {
                                    skeyValue = oView.byId("idMainMaterial").getTokens()[i].getProperty("key");
                                    if (i !== 0) {
                                        sMatValue = sMatValue + " or " + "Matnr eq '" + skeyValue + "'";
                                    }
                                    else {
                                        sMatValue = "Matnr eq '" + sMatValue + skeyValue + "'";
                                    }
                                });
                                var sFilter = "Werks eq '" + sPlantValue + "' and( " + sMatValue + ")";
                            }
                            //Maintaing filter value for single material
                            else {
                                sMaterialValue = oView.byId("idMainMaterial").getTokens()[0].getProperty("key");
                                var sFilter = "Matnr eq '" + sMaterialValue + "'";
                                var sFilter = "(Werks eq '" + sPlantValue + "'and Matnr eq'" + sMaterialValue + "')";
                            }

                            that.getOwnerComponent().getModel().read("/ProdColorsSet", {
                                urlParameters: {
                                    $filter: sFilter
                                },
                                success: $.proxy(function (oResponse) {
                                    that.getView().setModel(new JSONModel([]), "PLANT_EXCEL_RESULTS_MODEL");
                                    that.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").setData(oResponse.results);
                                    for (var skey = 0; skey < oResponse.results.length; skey++) {

                                        oeditItems.push({
                                            "ZzcolorCode": oResponse.results[skey].ZzcolorCode,
                                            "Matnr": oResponse.results[skey].Matnr,
                                            "Maktx": oResponse.results[skey].Maktx,
                                            "Werks": oResponse.results[skey].Werks,
                                            "ZzsortCriteria": oResponse.results[skey].ZzsortCriteria,
                                            "editable": ""
                                        });
                                    }
                                    that.getView().setModel(new JSONModel([]), "EDIT_RESULTS_MODEL");
                                    that.getView().getModel("EDIT_RESULTS_MODEL").setData(oeditItems);
                                    oView.byId("exportTable").setVisible(false);
                                    oView.byId("exportPlantTable").setVisible(true);
                                }, that),
                                error: function (oError) {
                                }
                            });
                        }
                        //Displaying error for not maintaining mandatory plant input
                        else {
                            MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("messageNoPlantValidation"));
                        }
                    }
                    //Condition :- Mandatory plant value is maintained without material code
                    else if (oView.byId("idMainPlant").getValue()) {
                        oView.byId("idSave").setVisible(true);
                        oView.byId("idCancel").setVisible(true);
                        var sPlantValue = oView.byId("idMainPlant").getValue();
                        that.getOwnerComponent().getModel().read("/ProdColorsSet",
                            {
                                urlParameters: {
                                    $filter: "Werks eq '" + sPlantValue + "'"
                                },
                                success: $.proxy(function (oResponse) {
                                    that.getView().setModel(new JSONModel([]), "PLANT_EXCEL_RESULTS_MODEL");
                                    that.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").setData(oResponse.results);
                                    oeditItems = [];
                                    for (var skey = 0; skey < oResponse.results.length; skey++) {
                                        oeditItems.push({
                                            "ZzcolorCode": oResponse.results[skey].ZzcolorCode,
                                            "Matnr": oResponse.results[skey].Matnr,
                                            "Maktx": oResponse.results[skey].Maktx,
                                            "Werks": oResponse.results[skey].Werks,
                                            "ZzsortCriteria": oResponse.results[skey].ZzsortCriteria,
                                            "editable": ""
                                        });
                                    }
                                    that.getView().setModel(new JSONModel([]), "EDIT_RESULTS_MODEL");
                                    that.getView().getModel("EDIT_RESULTS_MODEL").setData(oeditItems);
                                    oView.byId("exportTable").setVisible(false);
                                    oView.byId("exportPlantTable").setVisible(true);
                                }, that),
                                error: function (oError) {
                                }
                            });
                    }
                }
                //Displaying error for not maintaining any input paramters
                else {
                    MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("noinpputmessageBoxError"));
                }

            },

            //Event for handling sort criteria editable field
            onsortChange: function (oEvent) {
                var pathString = oEvent.getSource().getBindingContext("PLANT_EXCEL_RESULTS_MODEL").sPath.split("/")[1];
                this.getView().getModel("EDIT_RESULTS_MODEL").getData()[pathString].editable = true;

            },
            // Event for upload complete
            handleUploadComplete: function (oEvent) {
                // Calling upload complete function in utility file
                CommonUpload.handleComplete(oEvent);
            },

            // change event of File uploader
            onUploadChange: function (oEvent) {
                // Calling change function in utility file
                CommonUpload.handleUploadChange(oEvent);
            },

            //Event handling for the edit functionality ie rebinding to editable template
            onEdit: function () {
                this.plantRebindTable(this.oEditableTemplate, "Edit");
            },

            // Event for handling Create button click
            onPlantCreate: function () {
                var sPlantValue = oView.byId("idMainPlant").getValue();
                this.oCreateForm = sap.ui.xmlfragment("zftsclrcodegraphplnboard.fragments.CreateUI", this);
                this.getView().addDependent(this.oCreateForm);
                this.getView().setModel(new JSONModel([]), "PlantCreateModel");
                this.getView().getModel("PlantCreateModel").setProperty("/Pressed", true);
                this.oView.getModel("PlantCreateModel").setProperty("/PlantCodeValue", sPlantValue);
                this.oCreateForm.open();
            },

            //Function to rebind table used by file uploader
            rebindTable: function (oTemplate) {
                this.oTable.bindItems({
                    path: "/",
                    template: oTemplate,
                    templateShareable: 1,
                    model: "EXCEL_RESULTS_MODEL"
                });

            },

            //Function to rebind table based on plant/ material F4 values
            plantRebindTable: function (oTemplate) {
                this.oPlantTable.bindItems({
                    path: "/",
                    template: oTemplate,
                    templateShareable: 1,
                    model: "PLANT_EXCEL_RESULTS_MODEL"
                });

            },

            //Function handling the delete functionality for delete icon for table 
            handleDeleteAttachment: function (oEvent) {
                var oSelectedRow = oEvent.getSource().getParent().getBindingContext("PLANT_EXCEL_RESULTS_MODEL").getObject();
                var oTable = this.getView().byId("exportPlantTable");
                var oOriginalRows = oTable.getBinding("items").getModel("PLANT_EXCEL_RESULTS_MODEL").getProperty("/");

                for (var key in oOriginalRows) {
                    var oOriginalRow = oOriginalRows[key];
                    if (oOriginalRow === oSelectedRow) {
                        var sPlant = oOriginalRows[key].Werks;
                        var sMaterial = oOriginalRows[key].Matnr;
                        oOriginalRows.splice(key, 1);

                        oTable.getBinding("items").refresh(true);
                        odeleteItems.push({
                            "Plant": sPlant,
                            "Material": sMaterial
                        })
                        break;
                    }
                }
            },

            //Function to add newly maunally created entries for create fragment add button

            onCreateAdd: function () {
                var that = this;
                var sPlantValue = oView.getModel("PlantCreateModel").getProperty("/PlantCodeValue");;
                var sMaterialValue = oView.getModel("PlantCreateModel").getProperty("/MaterialCodeValue");
                if (sMaterialValue !== undefined) {

                    //Validation for plant and material combination already exists
                    var sFilter = "(Werks eq '" + sPlantValue + "'and Matnr eq'" + sMaterialValue + "')";
                    that.getOwnerComponent().getModel().read("/ProdColorExistSet", {
                        urlParameters: {
                            $filter: sFilter
                        },
                        async: true,
                        success: $.proxy(function (oResponse) {
                            if (oResponse.results.length === 0) {

                                var sColorCodeValue = that.oView.getModel("PlantCreateModel").getProperty("/ColorCodeValue");
                                var sMaterialCodeValue = that.oView.getModel("PlantCreateModel").getProperty("/MaterialCodeValue");
                                var sMaterialDescription = that.oView.getModel("PlantCreateModel").getProperty("/MaterialDescription");
                                var sMRPType = that.oView.getModel("PlantCreateModel").getProperty("/MRPType");
                                var sAdvancePlanning;
                                if (that.oView.getModel("PlantCreateModel").getProperty("/AdvancePlanning") === "X") {
                                    sAdvancePlanning = true;
                                }
                                else {
                                    sAdvancePlanning = false;
                                }
                                var sPlantCodeValue = that.oView.getModel("PlantCreateModel").getProperty("/PlantCodeValue");
                                var sSortCriteria = that.oView.getModel("PlantCreateModel").getProperty("/SortCriteria");

                                var onewItem = {
                                    "Werks": sPlantCodeValue,
                                    "Matnr": sMaterialCodeValue,
                                    "Maktx": sMaterialDescription,
                                    "ZzcolorCode": sColorCodeValue,
                                    "ZzsortCriteria": sSortCriteria,
                                    "Dismm": sMRPType,
                                    "Ppskz": sAdvancePlanning
                                };

                                opayloadItems.push({
                                    "ZzcolorCode": sColorCodeValue,
                                    "Matnr": sMaterialCodeValue,
                                    "Maktx": sMaterialDescription,
                                    "Werks": sPlantCodeValue,
                                    "ZzsortCriteria": sSortCriteria,
                                    "Dismm": sMRPType,
                                    "Ppskz": sAdvancePlanning
                                });

                                var oJSONseg = new JSONModel();
                                var aRegistros = that.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").getData();
                                aRegistros.push(onewItem);
                                oJSONseg.setData(aRegistros);
                                oView.setModel(oJSONseg, "PLANT_EXCEL_RESULTS_MODEL");
                                that.oCreateForm.close();
                            }

                            else {
                                MessageBox.error(that.getView().getModel("i18n").getResourceBundle().getText("CreateEntryDuplicate"));
                            }

                        }, that),
                        error: function (oError) {
                        }
                    });
                }
                else {
                    //Validation for mandatory field-Material Code for creation of new record
                    MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("CreateMandatoryFields"));
                }
            },

            //Event to handle close functionality for create frgament
            onCreateCancel: function () {
                this.getView().getModel("PlantCreateModel").setProperty("/Pressed", false);
                this.oCreateForm.close();
            },

            //Event to handle ok button functionality for Color Code F4 valuehelp
            onColorCodeValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");

                if (this.oView.getModel("PlantCreateModel").getData().Pressed === true) {

                    this.getView().getModel("PlantCreateModel").setProperty("/ColorCodeValue", aTokens[0].getProperty("key"));
                }
                else {
                    var spath = this.getView().getModel("PlantCreateModel").getProperty("/path");
                    this.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").setProperty(spath + "/ZzcolorCode", aTokens[0].getProperty("key"));

                    var pathString = this.getView().getModel("PlantCreateModel").getProperty("/path").split("/")[1];

                    this.getView().getModel("EDIT_RESULTS_MODEL").getData()[pathString].editable = true;

                }
                this._oVHD.close();
            },

            //Event to handle ok button functionality for Plant Code F4 valuehelp
            onPlantCodeValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                if (this.oView.getModel("PlantCreateModel").getData().Pressed === true) {
                    this.getView().getModel("PlantCreateModel").setProperty("/PlantCodeValue", aTokens[0].getProperty("key"));
                }
                else {
                    this.getView().getModel("MainModel").setProperty("/PlantCodeValue", aTokens[0].getProperty("key"));
                }
                this.getView().byId("idMainMaterial").setEditable(true);
                this._oPlantVHD.close();
            },

            //Event to handle ok button functionality for Material Code F4 valuehelp

            onMaterialCodeValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                if (this.oView.getModel("PlantCreateModel").getData().Pressed === true) {
                    var sMaterialDescription = aTokens[0].getAggregation("customData")[0].getProperty("value").Maktg;
                    var sMRPType = aTokens[0].getAggregation("customData")[0].getProperty("value").Dismm;
                    var sAdvancePlanning = aTokens[0].getAggregation("customData")[0].getProperty("value").Ppskz;
                    var sMaterial = aTokens[0].getAggregation("customData")[0].getProperty("value").Matnr;
                    this.getView().getModel("PlantCreateModel").setProperty("/MaterialDescription", sMaterialDescription);
                    this.getView().getModel("PlantCreateModel").setProperty("/MaterialCodeValue", sMaterial);
                    this.getView().getModel("PlantCreateModel").setProperty("/MRPType", sMRPType);
                    this.getView().getModel("PlantCreateModel").setProperty("/AdvancePlanning", sAdvancePlanning);
                    this.getView().getModel("PlantCreateModel").setProperty("/MaterialCodeValue", aTokens[0].getProperty("key"));
                }
                else {
                    oView.byId("idMainMaterial").setTokens(aTokens);
                }
                this._oMVHD.close();
            },

            //Event to handle launch MaterialCodeUI fragment for Material Code F4 valuehelp fragment

            onMaterialCodeHelpRequested: function () {

                var sPlantValue = oView.byId("idMainPlant").getValue();

                var sFilter = "Werks eq '" + sPlantValue + "'";

                this.getOwnerComponent().getModel().read("/Mat0mSet", {
                    urlParameters: {
                        $filter: sFilter
                    },
                    async: true,
                    success: $.proxy(function (oResponse) {
                        this.getView().setModel(new JSONModel([]), "MATERIAL_CODE_RESULTS_MODEL");
                        this.getView().getModel("MATERIAL_CODE_RESULTS_MODEL").setData(oResponse.results);
                        this.setMaterialDialog();

                    }, this),
                    error: function (oError) {
                    }
                });

            },

            //Creating Material Dialog for Material Code F4 valuehelp
            setMaterialDialog: function () {

                this._oMaterialBasicSearchField = new SearchField();
                Fragment.load({
                    name: "zftsclrcodegraphplnboard.fragments.MaterialCodeUI",
                    controller: this
                }).then(function (oMaterialDialog) {
                    var oMaterialFilterBar = oMaterialDialog.getFilterBar();
                    this._oMVHD = oMaterialDialog;
                    oView.addDependent(oMaterialDialog);

                    // Set Basic Search for FilterBar
                    oMaterialFilterBar.setFilterBarExpanded(false);
                    oMaterialFilterBar.setBasicSearch(this._oMaterialBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oMaterialBasicSearchField.attachSearch(function () {
                        oMaterialFilterBar.search();
                    });

                    oMaterialDialog.getTableAsync().then(function (oMaterialTable) {

                        oMaterialTable.setModel(oView.getModel("MATERIAL_CODE_RESULTS_MODEL"));
                        oMaterialTable.setSelectionBehavior("RowOnly");
                        var sMaterialCode = this.getView().getModel("i18n").getResourceBundle().getText("MaterialCode")
                        var sPlant = this.getView().getModel("i18n").getResourceBundle().getText("Plant")
                        var sMaterialDescription = this.getView().getModel("i18n").getResourceBundle().getText("MaterialDescription")
                        var sMRPController = this.getView().getModel("i18n").getResourceBundle().getText("MRPController")
                        var sProcurementType = this.getView().getModel("i18n").getResourceBundle().getText("ProcurementType")
                        var sMRPType = this.getView().getModel("i18n").getResourceBundle().getText("MRPType")
                        var sAdvancePlanning = this.getView().getModel("i18n").getResourceBundle().getText("AdvancePlanning")

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oMaterialTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            oMaterialTable.bindAggregation("rows", {
                                path: "/",
                                events: {
                                    dataReceived: function () {
                                        oMaterialDialog.update();
                                    }
                                }
                            });


                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sMaterialCode }), template: new Text({ wrapping: false, text: "{Matnr}" }), width: "14rem" }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sPlant }), template: new Text({ wrapping: false, text: "{Werks}" }) }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sMaterialDescription }), template: new Text({ wrapping: false, text: "{Maktg}" }) }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sMRPController }), template: new Text({ wrapping: false, text: "{Dispo}" }) }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sProcurementType }), template: new Text({ wrapping: false, text: "{Beskz}" }) }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sMRPType }), template: new Text({ wrapping: false, text: "{Dismm}" }) }));
                            oMaterialTable.addColumn(new UIColumn({ label: new Label({ text: sAdvancePlanning }), template: new Text({ wrapping: false, text: "{Ppskz}" }) }));
                        }

                        // For Mobile the default table is sap.m.Table
                        if (oMaterialTable.bindItems) {
                            // Bind items to the ODataModel and add columns
                            oMaterialTable.bindAggregation("items", {
                                path: "/",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{Matnr}" }), new Label({ text: "{Werks}" }), new Label({ text: "{Maktg}" }), new Label({ text: "{Dispo}" }), new Label({ text: "{Beskz}" }), new Label({ text: "{Dismm}" }), new Label({ text: "{Ppskz}" })]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oMaterialDialog.update();
                                    }
                                }
                            });
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sMaterialCode }), template: new Text({ wrapping: false, text: "{Matnr}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sPlant }), template: new Text({ wrapping: false, text: "{Werks}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sMaterialDescription }), template: new Text({ wrapping: false, text: "{Maktg}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sMRPController }), template: new Text({ wrapping: false, text: "{Dispo}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sProcurementType }), template: new Text({ wrapping: false, text: "{Beskz}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sMRPType }), template: new Text({ wrapping: false, text: "{Dismm}" }) }));
                            oMaterialTable.addColumn(new MColumn({ label: new Label({ text: sAdvancePlanning }), template: new Text({ wrapping: false, text: "{Ppskz}" }) }));
                        }
                        oMaterialDialog.update();
                    }.bind(this));
                    this._oMVHD.open();
                }.bind(this));

            },

            //Event to handle launch PlantCodeUI fragment for Plant Code F4 valuehelp
            onPlantHelpRequested: function () {

                this._oPlantBasicSearchField = new SearchField();
                Fragment.load({
                    name: "zftsclrcodegraphplnboard.fragments.PlantCodeUI",
                    controller: this
                }).then(function (oPlantDialog) {
                    var oPlantFilterBar = oPlantDialog.getFilterBar();
                    this._oPlantVHD = oPlantDialog;
                    oView.addDependent(oPlantDialog);

                    // Set key fields for filtering in the Define Conditions Tab


                    // Set Basic Search for FilterBar
                    oPlantFilterBar.setFilterBarExpanded(false);
                    oPlantFilterBar.setBasicSearch(this._oPlantBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oPlantBasicSearchField.attachSearch(function () {
                        oPlantFilterBar.search();
                    });

                    oPlantDialog.getTableAsync().then(function (oPlantTable) {

                        oPlantTable.setModel(oView.getModel("PLANT_RESULTS_MODEL"));
                        oPlantTable.setSelectionBehavior("RowOnly");
                        oPlantTable.setSelectionMode(sap.ui.table.SelectionMode.Single);
                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oPlantTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            oPlantTable.bindAggregation("rows", {
                                path: "/",
                                events: {
                                    dataReceived: function () {
                                        oPlantDialog.update();
                                    }
                                }
                            });
                            var splant = this.getView().getModel("i18n").getResourceBundle().getText("Plant");
                            var sname = this.getView().getModel("i18n").getResourceBundle().getText("Name");
                            var sname2 = this.getView().getModel("i18n").getResourceBundle().getText("Name2");


                            oPlantTable.addColumn(new UIColumn({ label: new Label({ text: splant }), template: new Text({ wrapping: false, text: "{Werks}" }) }));
                            oPlantTable.addColumn(new UIColumn({ label: new Label({ text: sname }), template: new Text({ wrapping: false, text: "{Name1}" }) }));
                            oPlantTable.addColumn(new UIColumn({ label: new Label({ text: sname2 }), template: new Text({ wrapping: false, text: "{Name2}" }) }));

                        }



                        // For Mobile the default table is sap.m.Table
                        if (oPlantTable.bindItems) {
                            // Bind items to the ODataModel and add columns
                            oPlantTable.bindAggregation("items", {
                                path: "/",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{Werks}" }), new Label({ text: "{Name1}" }), new Label({ text: "{Name2}" })]

                                }),
                                events: {
                                    dataReceived: function () {
                                        oPlantDialog.update();
                                    }
                                }
                            });
                            oPlantTable.addColumn(new MColumn({ header: new Label({ text: splant }) }));
                            oPlantTable.addColumn(new MColumn({ header: new Label({ text: sname }) }));
                            oPlantTable.addColumn(new MColumn({ header: new Label({ text: sname2 }) }));
                        }
                        oPlantDialog.update();
                    }.bind(this));


                    this._oPlantVHD.open();
                }.bind(this));

            },
            //Event to handle launch ColorCodeUI fragment for Color Code F4 valuehelp
            onColorCodeHelpRequested: function (oEvent) {

                this._oBasicSearchField = new SearchField();

                if (this.oView.getModel("PlantCreateModel").getData().Pressed !== true) {
                    this.getView().getModel("PlantCreateModel").setProperty("/path", oEvent.getSource().getBindingContext("PLANT_EXCEL_RESULTS_MODEL").getPath());
                }
                Fragment.load({
                    name: "zftsclrcodegraphplnboard.fragments.ColorCodeUI",
                    controller: this
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();
                    this._oVHD = oDialog;
                    oView.addDependent(oDialog);




                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(this._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    this._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {

                        oTable.setModel(oView.getModel("COLOR_CODE_RESULTS_MODEL"));
                        oTable.setSelectionBehavior("RowOnly");

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            // Bind rows to the ODataModel and add columns
                            oTable.bindAggregation("rows", {
                                path: "/",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            var sColorCode = this.getView().getModel("i18n").getResourceBundle().getText("ColorCode");
                            var sDescription = this.getView().getModel("i18n").getResourceBundle().getText("Description");

                            oTable.addColumn(new UIColumn({ label: new Label({ text: sColorCode }), template: new Text({ wrapping: false, text: "{Color}" }) }));
                            oTable.addColumn(new UIColumn({ label: new Label({ text: sDescription }), template: new Text({ wrapping: false, text: "{Ktext}" }) }));
                        }

                        // For Mobile the default table is sap.m.Table
                        if (oTable.bindItems) {
                            // Bind items to the ODataModel and add columns
                            oTable.bindAggregation("items", {
                                path: "/",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{Color}" }), new Label({ text: "{Ktext}" })]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });
                            oTable.addColumn(new MColumn({ header: new Label({ text: sColorCode }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: sDescription }) }));
                        }
                        oDialog.update();
                    }.bind(this));


                    this._oVHD.open();
                }.bind(this));
            },

            //Event to handle close MaterialCodeUI fragment for cancel button
            onMaterialCodeValueHelpAfterClose: function () {
                this._oMVHD.close();
            },
            //Event to handle close MaterialCodeUI fragment for cancel button
            onMaterialCodeValueHelpCancelPress: function () {
                this._oMVHD.destroy();
            },
            //Event to handle close PlantCodeUI fragment for cancel button
            onPlantCodeValueHelpAfterClose: function () {
                this._oPlantVHD.close();
            },
            //Event to handle destroy PlantCodeUI fragment for cancel button
            onPlantCodeValueHelpCancelPress: function () {
                this._oPlantVHD.destroy();
            },

            //Event to handle close ColorCodeUI fragment for cancel button
            onColorCodeValueHelpCancelPress: function () {
                this._oVHD.close();
            },

            //Event to handle destroy ColorCodeUI fragment for cancel button
            onColorCodeValueHelpAfterClose: function () {
                this._oVHD.destroy();
            },

            //Event for Save functionality that handles all create,delete and update functionality
            onSave: function (oEvent) {

                var that = this;
                that.getView().getModel("PlantCreateModel").setProperty("/Pressed", false);
                //Handling create functionality
                opayloadItems.forEach(function (oValue, i) {

                    that.getOwnerComponent().getModel().create("/ProdColorsSet", opayloadItems[i], {
                        method: "POST",
                        success: function (oData, oResponse) {
                            sap.m.MessageToast.show(that.getView().getModel("i18n").getResourceBundle().getText("RecordsCreated"));
                            that.plantRebindTable(that.oPlantReadOnlyTemplate, "Navigation");
                        },
                        error: function (oError, oResponse) {
                            var oErrorResponse = JSON.parse(oError.responseText);
                            var sErrorMessage = "";
                            if (oErrorResponse.error && oErrorResponse.error.innererror && oErrorResponse.error.innererror.errordetails && (oErrorResponse.error.innererror.errordetails.length) > 0) {
                                var aErrorDetails = oErrorResponse.error.innererror.errordetails;
                                for (var i = 0; i < aErrorDetails.length; i++) {
                                    sErrorMessage += aErrorDetails[i].message + "\n";
                                }
                            } else {
                                sErrorMessage = oErrorResponse.error.message.value;
                            }
                            MessageBox.error(sErrorMessage);
                        }
                    });

                });

                //Handling delete functionality
                odeleteItems.forEach(function (oValue, i) {

                    var sMaterial = odeleteItems[i].Material;
                    var sPlant = odeleteItems[i].Plant;

                    that.getOwnerComponent().getModel().remove("/ProdColorsSet(Werks='" + sPlant + "',Matnr='" + sMaterial + "')", {
                        method: "DELETE",
                        success: function (oData, oResponse) {
                            sap.m.MessageToast.show(that.getView().getModel("i18n").getResourceBundle().getText("RecordsDeleted"));
                            that.plantRebindTable(that.oPlantReadOnlyTemplate, "Navigation");
                        },
                        error: function (oError, oResponse) {
                            MessageBox.error(oError.message);
                        }
                    });
                });
                //Handling delete functionality
                oeditItems.forEach(function (oValue, i) {

                    if (oeditItems[i].editable === true) {
                        var oUpdatePayLoad = that.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").getData();
                        var sMaterial = oeditItems[i].Matnr;
                        var sPlant = oeditItems[i].Werks;

                        that.getOwnerComponent().getModel().update("/ProdColorsSet(Werks='" + sPlant + "',Matnr='" + sMaterial + "')", oUpdatePayLoad[i], {
                            method: "PUT",
                            success: function (oData, oResponse) {
                                sap.m.MessageToast.show(that.getView().getModel("i18n").getResourceBundle().getText("RecordsUpdated"));
                                oeditItems = [];
                                that.plantRebindTable(that.oPlantReadOnlyTemplate, "Navigation");
                            },
                            error: function (oError, oResponse) {
                                MessageBox.error(oError.message);
                            }
                        });
                    }
                });
            },

            //restting the model on cancel
            onCancel: function (oEvent) {
                if (this.getView().getModel("PLANT_EXCEL_RESULTS_MODEL") !== undefined) {
                    this.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").setData([]);
                }
                if (this.getView().getModel("EXCEL_RESULTS_MODEL") !== undefined)
                    this.getView().getModel("EXCEL_RESULTS_MODEL").setData([]);
                //this.getView().getModel("MainModel").setProperty("/MaterialCodeValue", "");
                this.getView().byId("idMainMaterial").removeAllTokens();
                this.getView().getModel("MainModel").setProperty("/PlantCodeValue", "");
                this.getView().byId("idMainMaterial").setEditable(false);
            },
            // Function to download template 
            handleDownloadTemplate: function (oEvent) {
                this.onExport("Template");
            },

            // Function to export data in plant/material table  
            onPlantExport: function (stype) {
                var aCols, aProducts, oSettings, oSheet, sExcelFileName;

                if (stype === "Template") {
                    aCols = this.createPlantTblColumns();
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("template");
                } else {
                    aCols = this.createPlantTblColumns();
                    aProducts = this.getView().getModel("PLANT_EXCEL_RESULTS_MODEL").getData();
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("template");
                }

                oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aProducts,
                    count: aProducts.length,
                    fileName: sExcelFileName,
                    wrap: true
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageBox.information(this.getView().getModel("i18n").getResourceBundle().getText("messageBoxInformation"));
                    })
                    .finally(oSheet.destroy);
            },

            //creating columns for plant/material table
            createPlantTblColumns: function () {
                return [
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("PlantM"),
                        property: 'Werks',
                        type: EdmType.String,
                        width: 11

                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("MaterialM"),
                        property: 'Matnr',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("DescriptionM"),
                        property: 'Maktx',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("ColorM"),
                        property: 'ZzcolorCode',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("SortM"),
                        property: 'ZzsortCriteria',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("MRPType"),
                        property: 'Dismm',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("AdvancePlanning"),
                        property: 'Ppskz',
                        type: EdmType.String,
                        width: 11
                    }
                ];
            },

            // Function to export data in file uploader table    
            onExport: function (stype) {
                var aCols, aProducts, oSettings, oSheet, sExcelFileName;

                if (stype === "Template") {
                    aCols = this.createTemplateColumns();
                    aProducts = [{
                        "PLANT": "",
                        "MATERIALCODE": "",
                        "MATERIALCODE": "",
                        "COLORCODE": "",
                        "SORTCRITERIA": ""
                    }];
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("template");
                } else {
                    aCols = this.createTblColumns();
                    aProducts = this.getView().getModel("EXCEL_RESULTS_MODEL").getData();
                    sExcelFileName = this.getView().getModel("i18n").getResourceBundle().getText("template");
                }

                oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aProducts,
                    count: aProducts.length,
                    fileName: sExcelFileName,
                    wrap: true
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageBox.information(this.getView().getModel("i18n").getResourceBundle().getText("messageBoxInformation"));
                    })
                    .finally(oSheet.destroy);
            },
            // Building labels & properties for excel
            createTblColumns: function () {
                return [
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("PlantM"),
                        property: 'PLANT',
                        type: EdmType.String,
                        width: 11

                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("MaterialM"),
                        property: 'MATERIALCODE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("DescriptionM"),
                        property: 'MATERIALDESCRIPTION',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("ColorM"),
                        property: 'COLORCODE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("SortM"),
                        property: 'SORTCRITERIA',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("Status"),
                        property: 'STATUS',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("Message"),
                        property: 'MESSAGE',
                        type: EdmType.String,
                        width: 11
                    }
                ];
            },

            // Building labels & properties for template excel
            createTemplateColumns: function () {
                return [
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("PlantM"),
                        property: 'PLANT',
                        type: EdmType.String,
                        width: 11

                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("MaterialM"),
                        property: 'MATERIALCODE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("DescriptionM"),
                        property: 'MATERIALDESCRIPTION',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("ColorM"),
                        property: 'COLORCODE',
                        type: EdmType.String,
                        width: 11
                    },
                    {
                        label: this.getView().getModel("i18n").getResourceBundle().getText("SortM"),
                        property: 'SORTCRITERIA',
                        type: EdmType.String,
                        width: 11
                    }
                ];
            },

            //Filter functionality for ColorCode ValueHelp
            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Color", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Ktext", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterColorValueTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },

            //Filter functionality for ColorCode ValueHelp
            _filterColorValueTable: function (oFilter) {
                var oVHD = this._oVHD;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },
            //Filter functionality for MaterialCode ValueHelp
            onMaterialCodeFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oMaterialBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Matnr", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Maktg", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Dispo", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Dismm", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "Ppskz", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterMaterialCodeValueTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            //Filter functionality for MaterialCode ValueHelp
            _filterMaterialCodeValueTable: function (oFilter) {
                var oMVHD = this._oMVHD;

                oMVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oMVHD.update();
                });

            },

            //Filter functionality for PlantCode ValueHelp
            onPlantCodeFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oPlantBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "Werks", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterPlantCodeValueTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },

            //Filter functionality for PlantCode ValueHelp
            _filterPlantCodeValueTable: function (oFilter) {
                var oPlantVHD = this._oPlantVHD;

                oPlantVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }
                    // This method must be called after binding update of the table.
                    oPlantVHD.update();
                });
            }
        });
    });
