sap.ui.define([
	"zfts_clr_code_graph_pln_board/test/unit/controller/ReportView.controller"
], function () {
	"use strict";
});
