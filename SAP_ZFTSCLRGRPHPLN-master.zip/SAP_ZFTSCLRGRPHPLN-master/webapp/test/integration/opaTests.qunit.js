/* global QUnit */

sap.ui.require(["zftsclrcodegraphplnboard/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
